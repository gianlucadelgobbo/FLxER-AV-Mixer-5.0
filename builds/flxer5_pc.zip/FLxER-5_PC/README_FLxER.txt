///////////////////////////////////////////
/                                         /
/ XXXXX X     X   X xxxxx xxxx            /
/ X     X      X X  x     x   x           /
/ XXX   X       X   xxx   xxxx            /
/ X     X      X X  x     x  x            /
/ X     XXXXX X   X xxxxx x   x    v5     /
/                                         /
///////////////////////////////////////////

>> BEFORE START ___________________________

FLxER is a free software made with internet technology so for security reasons doesn't read the content of your hard disk. every video file and plug-in, wipe, effect, has to be added to the xml files that the application loads before to start.

>> STARTING _____________________________

1) NO INSTALLATION IS REQUIRED, launch the application FLxER-5.app (MAC) / FLxER-5.exe (PC) / FLxER-5.swf and take a tour of the functionality start from "select playlist" and load some movie.

LINUX ONLY (SOMETIMES)
You need to complete a couple of steps before launching the application FLxER-5.swf.

1.a) Download the Linux Flash Player 10.1 Projector (TAR.GZ, 4.02 MB) 
available at http://www.adobe.com/support/flashplayer/downloads.html

1.b) Visit the on-line Adobe 'setting manager' to modify your global security settings
http://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager.html

1.c) From the menu on the left select 'Global Security Settings panel'

1.d) Click on 'Edit locations...'

1.e) From the drop-down menu choose 'Add location'

1.f) 'Browse for files...' on your local resources and select:
- FLxER-5.swf
- FLxER-5monitorOut.swf
- FLxER-5remoteOut.swf
- OaxoaTiles.swf
- SVGwipesDrawer.swf

1.g) Click 'Confirm'

You are now ready to fire FLxER on your machine!


2) If you enjoy FLxER and you want to try playing with your movies and files you have to modify the configuration files manually or using "FLxEReasyPlaylistsBuilder.jar".

2.a) First step: copy your files into a folder (the name of the folder will be the name of the playlist) into "library/".

2.b) Run FLxEReasyPlaylistsBuilder.jar

3) Run FLxER


UPGRADING FLxER  __________________________

1) Unzip FLxER-5 in a new folder

2) overwrite the library folder with your old FLxER library folder

3) Run FLxEReasyPlaylistsBuilder.jar

If you came from FLxER 3 or previous versions or you have custom libraries

4) open your old "preferences/flxer_pref.flx" and copy all the rows of of libraries files name (inside the node <libraries>)

5) open the new "preferences/playlists.xml" and paste it into the node (<playlists>)

6) copy all the playlists inside "playlists" folder


FLxER 5 FEATURES __________________________

- 7 channels video mixer

- Supported media: .swf (full ActionScrpt 3 support), .flv and all h.264, .jpg, .gif, .png, .txt, .mp3

- Advanced live text editor over all channels

- DV-IN Analog and digital over all channels

- HD output resolution starting from 800x600

- Full Colors and Trasform palette

- 14 Blend options over all channels

- Effects and Analog effects as blur over all channels

- Completly customizable list of Wipes

- Video Sequencer  over all channels

- XML VIDEO RECORDER to share or recall your livesets in a few bytes

- XML VIDEO PLAYER

- BROADCAST VIDEO DELIVERY to share in real time your liveset all over the world or to use more pc to do a live set

- BROADCAST VIDEO PLAYER

- 3D Engine

- Mapping Tools

- HD output resolution starting from 800x600

- Full Colors and Trasform palette

- 14 Blend options over all channels

- Effects and Analog effects as blur over all channels

- Full customizable list of Wipes

- Video Sequencer  over all channels

- XML VIDEO RECORDER to share or recall your live sets in a few bytes

- XML VIDEO PLAYER

- BROADCAST VIDEO DELIVERY to share in real time your live set all over the world or to use more pc to do a live set

- BROADCAST VIDEO PLAYER
